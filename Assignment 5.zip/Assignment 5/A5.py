file = open("C:\\Users\Andrew Megrditchian\\Desktop\\Intro to Python\\M5\\ToDo.txt", "r") #opens text file
list = [] #creates list
for line in file: #reads text file and adds each line as item in list
    list.append(line)
file.close()
print(list) #displays list
dic = {} #creates dictionary
for item in list: #splits items in list at "," and enters them into dictionary
    c = item.split(",")
    a = c[0]
    b = c[1]
    dic[a] = b
print(dic) #displays dictionary
while 1 == 1: #while loop lets you display, add, remove, as well as save and exit.
    print('''OPTIONS
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Exit Program and Write''')
    entry = input("Enter option number: ")
    if entry == "1":
        print(dic)
    elif entry == "2":
        key = input("Enter task: ")
        value = input("Enter priority: ")
        dic[key] = value
        print(dic)
    elif entry == "3":
        key = input("Enter key in deletion: ")
        del dic[key]
        print(dic)
    elif entry == "4":
        s = str(dic)
        file = open("C:\\Users\Andrew Megrditchian\\Desktop\\Intro to Python\\M5\\ToDo.txt", "w")
        file.write(s)
        file.close()
        break
